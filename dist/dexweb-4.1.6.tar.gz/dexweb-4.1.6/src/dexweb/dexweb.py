class Dexweb:
    def __init__(self, dexname):
        self.dexname = dexname