Dexweb builds you a dex to put on the web. Dexweb generates a website from PDF, Powerpoint, document, text, and JSON files.

A dex is free programmatically generated website. Dexs are used to put research papers, research protocols, company documentation, books, articles and presentations on the Internet for free. Anywhere text is generated with algorithms like in research or company finances, a dex can be used to put data on the web. Dex is a standardized format for publishing simple websites optimized for PC, mobiles and tablets.

Latest version 4.1.9 fixes duplicate additions to existing page objects when adding new files in /to_add folder

```bash
pip install dexweb
```

[Documentation](https://matrixdex.github.io/dexweb)is a dex. Meta we know!



Dependencies:

- pypdf==5.1.0
- beautifulsoup4==4.12.3
- mammoth==1.8.0
- importlib_resources




## License

This project is released under the Creative Commons Zero license.