Dexweb builds you a dex to put on the web. Dexweb generates a website from PDF, Powerpoint, document, text, and JSON files.

A dex is free programmatically generated website. Dexs are used to put research papers, research protocols, company documentation, books, articles and presentations on the Internet for free. Anywhere text is generated with algorithms like in research or company finances, a dex can be used to put data on the web. Dex is a standardized format for publishing simple websites optimized for PC, mobiles and tablets.

Versions/
4.2.4 fixes dexweb publishing bug
4.2.3 adds dexweb.Dexweb().publish(). Publish gen/ to a git repository or a folder.
4.2.2 updates root The Matrix Dex (thematrix.json) and base styles.css files
4.2.1 fixes javascript injection failures from config.json to pages
4.2.0 adds sample dex called The Matrix Dex. Use it as self-referential text. Generated on blank dex name.

```bash
pip install dexweb
```

[Documentation](https://matrixdex.github.io/dexweb) is a dex. Meta we know!



Dependencies:

- pypdf==5.1.0
- beautifulsoup4==4.12.3
- mammoth==1.8.0
- importlib_resources




## License

This project is released under the Creative Commons Zero license.